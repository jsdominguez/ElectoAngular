var control = angular.module("eleccion", ['ngMessages']);

control.controller("main", function($scope, $http) {
  $http.get("PHP/votos.php").success(function(data) {
    $scope.res = data;
  });

  $scope.votar = function(datos) {
    $http.post("PHP/insert.php", datos).success(function(info) {
      var mensage = info;
      //location.reload(true);
      if (mensage.length > 0)
      {
        $scope.datosincorrectos = mensage;
        $scope.validar = "validarnumero";
      } else
      {
        $http.get("PHP/votos.php").success(function(data) {
          $scope.res = data;
        });
        swal({
          title: "Genial!",
          text: "Gracias por participar en esta simulacion de voto electoral.",
          imageUrl: "img/pelo.jpg"
        });
      }
    });
  };

});
